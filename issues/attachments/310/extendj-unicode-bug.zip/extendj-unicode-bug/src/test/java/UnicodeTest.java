import beaver.Symbol;
import org.extendj.parser.JavaParser;
import org.extendj.scanner.JavaScanner;
import org.junit.Test;

import java.io.StringReader;

public class UnicodeTest {

    @Test
    public void simpleChar() throws Exception {
        JavaScanner scanner = new JavaScanner(new StringReader("\":o\""));
        tokenize(scanner);
    }

    @Test
    public void unicodeChar() throws Exception {
        JavaScanner scanner = new JavaScanner(new StringReader("\"😯\""));
        tokenize(scanner);
    }

    @Test
    public void escapedUnicodeChar() throws Exception {
        JavaScanner scanner = new JavaScanner(new StringReader("\"\uD83D\uDE2F\""));
        tokenize(scanner);
    }

    @Test
    public void escapedEscapedUnicodeChar() throws Exception {
        JavaScanner scanner = new JavaScanner(new StringReader("\"\\uD83D\\uDE2F\""));
        tokenize(scanner);
    }

    private static void tokenize(JavaScanner scanner) throws Exception {
        Symbol symbol;

        while ((symbol = scanner.nextToken()).getId() != JavaParser.Terminals.EOF) {
            System.out.printf("Symbol ID: %3s Value '%s' (%s)%n", symbol.getId(), symbol.value, symbol.value.getClass());
        }
    }
}
