import com.amazonaws.services.s3.AmazonS3Client;

public class AmazonS3ClientExample {
	public static void main(String[] args) {
		AmazonS3Client amazonS3Client = new AmazonS3Client();
	}
}

//"C:\Program Files\Java\jdk1.7.0_71\bin\java.exe" -jar extendj_bb_j7.jar -cp lib/aws-java-sdk-s3.jar src/AmazonS3ClientExample.java -XdumpTree
//"C:\Program Files\Java\jdk1.8.0_77\bin\java.exe" -jar extendj_bb_j8.jar -cp lib/aws-java-sdk-s3.jar src/AmazonS3ClientExample.java -XdumpTree
