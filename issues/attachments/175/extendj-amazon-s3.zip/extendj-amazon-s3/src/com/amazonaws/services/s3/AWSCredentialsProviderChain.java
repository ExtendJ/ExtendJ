package com.amazonaws.services.s3;

public class AWSCredentialsProviderChain {
	public AWSCredentialsProviderChain(AWSCredentialsProvider... credentialsProviders) {
		super();
	}

	public Object getCredentials() {
		return null;
	}

}
