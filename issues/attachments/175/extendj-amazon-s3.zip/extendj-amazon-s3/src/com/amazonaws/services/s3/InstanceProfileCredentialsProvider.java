package com.amazonaws.services.s3;

public class InstanceProfileCredentialsProvider implements
		AWSCredentialsProvider {

}
