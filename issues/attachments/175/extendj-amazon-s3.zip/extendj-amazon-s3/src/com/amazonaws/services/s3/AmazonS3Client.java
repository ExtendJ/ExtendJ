package com.amazonaws.services.s3;

public class AmazonS3Client {

	public AmazonS3Client() {
		this(new AWSCredentialsProviderChain(new InstanceProfileCredentialsProvider()) {
			public Object getCredentials() {
				return new Object();
			}
		});
	}

	public AmazonS3Client(AWSCredentialsProviderChain credentialsProviderChain) {
		super();
	}
}
