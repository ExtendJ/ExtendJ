package com.amazonaws.services.s3;

public interface AWSCredentialsProvider {

}
